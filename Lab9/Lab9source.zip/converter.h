/* 
 * File:   converter.h
 * Author: Pike
 *
 */

#ifndef CONVERTER_H
#define	CONVERTER_H

#include <string>
using namespace std;

int Binary_to_Decimal(string b_num);
void Decimal_to_Binary(int d_num);
bool valid_parentheses(string E);

#endif	/* CONVERTER_H */

