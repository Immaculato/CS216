//converter.cpp

#include <iostream>
#include "converter.h"
#include "stack.h"


int Binary_to_Decimal(string b_num)
{
    //function for converting binary to decimal

    int d_num = 0;
    for (int i = 0; i < b_num.length(); i++)
    {
        if (b_num.substr(i,1) == "0")
            d_num = 2 * d_num;
        else if (b_num.substr(i,1) == "1")
                d_num = 2 * d_num + 1;
             else {
                 cout << "it contains invalid digit." << endl;
                 return -1;
             }    
    }
    return d_num;   
}

void Decimal_to_Binary(int d_num)
{
    //function for converting decimal to binary
            
    char digit;
    Stack toReverse;
    
    cout << "Decimal:" << d_num; 
    
    while (d_num > 0)
    {
        digit = d_num % 2 + '0';
        toReverse.push(digit);
        d_num = d_num / 2;
    } 
    
    if (toReverse.empty())
    {
        cout << endl << "Invalid Decimal Number" << endl;
        return;
    }
    cout  << "--> Binary: ";
    while (!toReverse.empty())
    {
        cout << toReverse.stackTop();
        toReverse.pop();
    } 
    cout << endl;
}

bool valid_parentheses(string E)
{

}
